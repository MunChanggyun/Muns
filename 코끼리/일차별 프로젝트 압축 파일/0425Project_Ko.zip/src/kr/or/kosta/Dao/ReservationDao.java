package kr.or.kosta.Dao;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ReservationDao {
	DataSource datasource =  null;
	Connection conn = null;
	
	public ReservationDao(){
		Context context;
		try {
			context = new InitialContext();
			datasource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}		
	}
	
	public void ReservationWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public void ReservationDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void ReservationList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public void FacilityNameByCode(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public void TimeWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void TimeDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void TimeList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	} 
}
