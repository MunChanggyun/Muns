package kr.or.kosta.Service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;
import kr.or.kosta.Dto.MemberDto;

public class MemberListService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) {
			ActionForward forward =null;
			ArrayList<MemberDto> memberlist = null;
			try{
				
				MemberDao dao = new MemberDao();
				memberlist = dao.MemberAllList();
				forward = new ActionForward();
				if(memberlist!=null){
					System.out.println("true");
					request.setAttribute("memberlist", memberlist);
					forward.setPath("member/MemberList.jsp");
					forward.setRedirect(false);
					
				}else{
					System.out.println("false");
					forward.setPath("main.jsp");
					forward.setRedirect(false);
				}
				
			}catch(Exception e){
				
				
			}
		return forward;
	}

}
