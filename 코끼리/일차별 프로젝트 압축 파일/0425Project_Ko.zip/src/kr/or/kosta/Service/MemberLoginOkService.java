package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;





public class MemberLoginOkService implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = null;
		String memberid = request.getParameter("memberid");
		String memberpw = request.getParameter("memberpw");
		
		try{
			forward = new ActionForward();
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html; charset=UTF-8");
			MemberDao memberDao = new MemberDao();
			
			
			boolean check = memberDao.MemberLogin(memberid, memberpw);
			
			
			forward.setRedirect(false);
			forward.setPath("index.jsp");
			
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}

}
