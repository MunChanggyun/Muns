package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;

public class MemberPwdSearchOkService implements Action  {

	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) {
		ActionForward forward = null;
		int result = 0;
		String member_newpw = request.getParameter("member_newpw");
		String member_id = (String) request.getAttribute("member_id");
		try{
		MemberDao memberDao = new MemberDao();
		
		result = memberDao.MemberPasswordEdit(member_newpw, member_id);
		
		forward.setRedirect(false);
		forward.setPath("index.jsp");
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
	
}