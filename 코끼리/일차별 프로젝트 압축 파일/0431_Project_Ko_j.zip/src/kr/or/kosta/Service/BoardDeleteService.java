package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.BoardDao;

public class BoardDeleteService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		
		BoardDao boardDao = new BoardDao();
		ActionForward forward = null;
		
		try{
			request.setCharacterEncoding("utf-8");
			
			forward = new ActionForward();
			String idx = request.getParameter("boardIdx");
			int categoryCode = Integer.parseInt(request.getParameter("categoryCode"));
			String cpage =	request.getParameter("cp"); // 현재 페이지 번호
		    String psize =	request.getParameter("ps"); // page size
		    
		    // 글번호를 가지고 오지 않았을 경우 예외처리
		 	if(idx == null || idx.trim().equals("")){
		 		// 원래 있던 페이지로 넘어가기
		 		response.sendRedirect("/Certain.board?categoryCode="+categoryCode);
		 	}
		 	
		 	int boardIdx = Integer.parseInt(idx.trim());
		 	System.out.println("boardIdx : " + boardIdx);
		
		    if(cpage==null || cpage.trim().equals("")){
				cpage="1";
			}
			if(psize==null || psize.trim().equals("")){
				psize="5";
			}
			// 댓글 삭제
			int rowcnt1 = boardDao.CommentAllDelete(boardIdx);
			
			// 첨부파일 삭제
			int rowcnt2 = boardDao.BoardFileDelete(boardIdx);
			
			// 게시물 삭제
			int rowcnt3 = boardDao.BoardDelete(boardIdx);
			
			if(rowcnt1 > 0 && rowcnt2 > 0 && rowcnt3 > 0){
				System.out.println("글 삭제 성공");
				request.setAttribute("result", "success");
			}else{
				System.out.println("글 삭제 실패");
				request.setAttribute("result", "fail");
			}
			request.setAttribute("boardIdx", boardIdx);
			request.setAttribute("cpage", cpage);
			request.setAttribute("psize", psize);
			
			forward.setRedirect(false);
			forward.setPath("/Certain.board?categoryCode="+categoryCode+"&cpage="+cpage+"&psize="+psize); // 게시물이 있던 리스트 페이지?cpage=?,pasize=?로 넘어가기
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
}
