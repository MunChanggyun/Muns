package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.BoardDao;
import kr.or.kosta.Dto.BoardDto;

public class BoardEditPageService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		String idx = request.getParameter("idx"); // �۹�ȣ
		ActionForward forward = null;
		
		try{
			if(idx == null || idx.trim().equals("")){
				response.sendRedirect("board_list.jsp"); // ���� �ִ� ��������
			}
			
			int boardIdx = Integer.parseInt(idx.trim());
			BoardDao boardDao = new BoardDao();
			BoardDto boardDto = boardDao.BoardgetContentByBoardId(boardIdx);		
			
			if(boardDto == null){
				System.out.println("������ ����");
				response.sendRedirect("board_list.jsp"); // ���� �ִ� ��������
			}
			
			forward = new ActionForward();
		    request.setAttribute("boardDto", boardDto);
		    request.setAttribute("idx", boardIdx);
		    
		    forward.setRedirect(false);
			forward.setPath("/board/board_edit.jsp"); // ���� ��������
		}catch(Exception e){
			System.out.println(e.getMessage());
		}		
		return forward;
	}
}
