package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;

public class MemberPwdSearchService implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) {
		
		ActionForward forward = null;
		boolean check = false;
		String member_dong = request.getParameter("member_dong");
		String member_ho = request.getParameter("member_ho");
		String member_id = request.getParameter("member_id");
		try{
			MemberDao memberDao = new MemberDao();
			
			check = memberDao.MemberPwdSearchById(member_dong, member_ho, member_id);
			if(check){
				request.setAttribute("member_id", member_id);	
			}else{
				forward.setPath("memberpwdsearch.jsp");
			}
			
			forward.setRedirect(false);
			forward.setPath("memberpwdsearchok.jsp");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
	
}