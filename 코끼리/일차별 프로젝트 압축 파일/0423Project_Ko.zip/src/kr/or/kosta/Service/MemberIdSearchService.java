package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;



public class MemberIdSearchService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) {
		ActionForward forward = null;
		
		String member_zipcode = request.getParameter("member_zipcode");
		String member_dong = request.getParameter("member_dong");
		String member_ho = request.getParameter("member_ho");	
		try{
			
		
		MemberDao memberDao = new MemberDao();
		
		String id = memberDao.MemberIdSearchByZipcode(member_zipcode, member_dong, member_ho);
		
		forward.setRedirect(false);
		forward.setPath("MemberIdSearchOk.jsp");
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
			return forward;
		}
		
	}
	
