package kr.or.kosta.Dto;

import java.util.Date;

public class ReservationDto {
	private int reservation_id;
	private String facility_id;
	private String member_id;
	private Date time_date;
	
	public ReservationDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReservationDto(int reservation_id, String facility_id,
			String member_id, Date time_date) {
		super();
		this.reservation_id = reservation_id;
		this.facility_id = facility_id;
		this.member_id = member_id;
		this.time_date = time_date;
	}
	public int getReservation_id() {
		return reservation_id;
	}
	public void setReservation_id(int reservation_id) {
		this.reservation_id = reservation_id;
	}
	public String getFacility_id() {
		return facility_id;
	}
	public void setFacility_id(String facility_id) {
		this.facility_id = facility_id;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public Date getTime_date() {
		return time_date;
	}
	public void setTime_date(Date time_date) {
		this.time_date = time_date;
	}
	@Override
	public String toString() {
		return "ReservationDto [reservation_id=" + reservation_id
				+ ", facility_id=" + facility_id + ", member_id=" + member_id
				+ ", time_date=" + time_date + "]";
	}
	
}
