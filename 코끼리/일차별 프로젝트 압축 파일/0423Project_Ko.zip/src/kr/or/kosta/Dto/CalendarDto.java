package kr.or.kosta.Dto;

import java.util.Date;

public class CalendarDto {
	private String manager_id;
	private String calendar_content;
	private Date calendar_start;
	private Date calendar_end;
	
	public CalendarDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CalendarDto(String manager_id, String calendar_content,
			Date calendar_start, Date calendar_end) {
		super();
		this.manager_id = manager_id;
		this.calendar_content = calendar_content;
		this.calendar_start = calendar_start;
		this.calendar_end = calendar_end;
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public String getCalendar_content() {
		return calendar_content;
	}
	public void setCalendar_content(String calendar_content) {
		this.calendar_content = calendar_content;
	}
	public Date getCalendar_start() {
		return calendar_start;
	}
	public void setCalendar_start(Date calendar_start) {
		this.calendar_start = calendar_start;
	}
	public Date getCalendar_end() {
		return calendar_end;
	}
	public void setCalendar_end(Date calendar_end) {
		this.calendar_end = calendar_end;
	}
	@Override
	public String toString() {
		return "CalendarDto [manager_id=" + manager_id + ", calendar_content="
				+ calendar_content + ", calendar_start=" + calendar_start
				+ ", calendar_end=" + calendar_end + "]";
	}
	
}
