package kr.or.kosta.Dto;

public class BoardFileDto {
	private int board_id;
	private String board_file;
	
	public BoardFileDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBoard_id() {
		return board_id;
	}

	public void setBoard_id(int board_id) {
		this.board_id = board_id;
	}

	public String getBoard_file() {
		return board_file;
	}

	public void setBoard_file(String board_file) {
		this.board_file = board_file;
	}

	@Override
	public String toString() {
		return "BoardFileDto [board_id=" + board_id + ", board_file="
				+ board_file + "]";
	}

}
