package kr.or.kosta.Filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebFilter("/view/manager/*")
public class AuthorityFilter implements Filter {
 

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

  
    public AuthorityFilter() {
        // TODO Auto-generated constructor stub
    }


	public void destroy() {
		// TODO Auto-generated method stub
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		
		HttpServletRequest h_request= (HttpServletRequest) request;
		HttpServletResponse h_response= (HttpServletResponse) response;
				
		HttpSession h_session= h_request.getSession();
		int authority=  (int)h_session.getAttribute("session_authority");
		
		if(authority==1){	
			h_response.sendRedirect("/0427Project_Ko/Certain.board?categoryCode=1");
		}else if(h_session.getAttribute("session_authority") == null){
			h_response.sendRedirect("/0427Project_Ko/view/homepage.jsp");
		}else{
			System.out.println("[필터]: 관리자로 들어갑니다.");
		}		
		chain.doFilter(request, response);
	}
}
