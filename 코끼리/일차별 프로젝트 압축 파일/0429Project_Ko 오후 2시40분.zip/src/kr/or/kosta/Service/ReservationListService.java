package kr.or.kosta.Service;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.ReservationDao;
import kr.or.kosta.Dto.ReservationDto;


public class ReservationListService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) {
				System.out.println("aaaaa");
				String member_id = request.getParameter("member_id");
				ActionForward forward = new ActionForward();
				
				ReservationDao reservationdao = new ReservationDao();
				ArrayList<ReservationDto> reservationlist = new ArrayList<ReservationDto>();
				reservationlist = reservationdao.ReservationList(member_id);
				System.out.println(reservationlist);
				if(reservationlist!=null){
					request.setAttribute("reservationlist", reservationlist);
					forward.setPath("/view/reservation/ReservationList.jsp");
					forward.setRedirect(false);
				}else{
					forward.setPath("/view/reservation/Reservation.jsp");
					forward.setRedirect(false);
				}
					
		
		
		
		return forward;
	
		
		
		
	}
	
}