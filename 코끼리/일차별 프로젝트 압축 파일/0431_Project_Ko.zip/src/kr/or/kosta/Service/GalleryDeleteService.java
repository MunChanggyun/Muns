package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.GalleryDao;

public class GalleryDeleteService implements Action{
	
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		//int gallery_id = Integer.parseInt(request.getParameter("gallery_id"));
		int gallery_id = Integer.parseInt(request.getParameter("gallery_id"));
		System.out.println(gallery_id);
		
		GalleryDao galleryDao = new GalleryDao();
		ActionForward forward = null;
		
		try{
			request.setCharacterEncoding("utf-8");
			
			forward = new ActionForward();
			String cpage = request.getParameter("cp"); //현재 페이지
			String psize = request.getParameter("ps"); //페이지 사이즈 
			if(gallery_id == 0){
				response.sendRedirect("gallery_list.jsp"); // 갤러리가 있던 리스트 페이지로 넘어가기
			}
			
			int result = galleryDao.GalleryDelete(gallery_id);
			System.out.println(result);
			if(result > 0){
				System.out.println("글 삭제 성공");
				request.setAttribute("result", "success");
			}else{
				System.out.println("글 삭제 실패");
				request.setAttribute("result", "fail");
			}
			
			System.out.println("fffffffffffff");
			request.setAttribute("gallery_id", gallery_id);
			System.out.println("uuuuuuuuuuuuuuuuuuu");
			request.setAttribute("cpage", cpage);
			System.out.println("cccccccccccccccccccccc");
			request.setAttribute("psize", psize);
			System.out.println("kkkkkkkkkkkkkkk");
			forward.setPath("/Gallery.board");
			forward.setRedirect(false);
			
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
}