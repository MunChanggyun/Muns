package kr.or.kosta.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class ApartmentDao {
	DataSource datasource =  null;
	Connection conn = null;
	
	public ApartmentDao(){
		Context context;
		try {
			context = new InitialContext();
			datasource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}		
	}
	
	public void SeoulList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void ApartmentList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
