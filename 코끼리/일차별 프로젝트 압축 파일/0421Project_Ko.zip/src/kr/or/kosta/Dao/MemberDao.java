package kr.or.kosta.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import kr.or.kosta.Dto.MemberDto;

public class MemberDao {
	DataSource datasource = null;
	Connection conn = null;

	public MemberDao() {
		Context context;
		try {
			context = new InitialContext();
			datasource = (DataSource) context
					.lookup("java:comp/env/jdbc/oracle");
			conn = datasource.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public ArrayList<MemberDto> MemberAllList() {
		ArrayList<MemberDto> memberlist = null;
		try {

			PreparedStatement psmt = null;
			String sql = "select * from MEMBER";
			psmt = conn.prepareStatement(sql);

			ResultSet rs = psmt.executeQuery();

			memberlist = new ArrayList<MemberDto>();

			while (rs.next()) {
				MemberDto m = new MemberDto();
				m.setMember_id(rs.getString("MEMBER_ID"));
				m.setMember_pw(rs.getString("MEMBER_PW"));
				m.setMember_authority(rs.getInt("MEMBER_AUTHORITY"));
				m.setMember_zipcode(rs.getString("MEMBER_ZIPCODE"));
				m.setMember_dong(rs.getString("MEMBER_DONG"));
				m.setMember_ho(rs.getString("MEMBER_HO"));
				memberlist.add(m);
			}
			rs.close();
			psmt.close();
			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return memberlist;

	}

	public void MemberPasswordEdit() {
		try {

			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public int MemberDelete(String id) {
		int row = 0;
		try {
			PreparedStatement psmt = null;

			String sql = "delete from member where member_id=?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			row = psmt.executeUpdate();

			if (row > 0) {
				conn.commit();
			} else {
				conn.rollback();
			}
			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return row;
	}

	public int MemberJoin(String member_id, String member_pw,
			int member_authority, String member_zipcode, String member_dong,
			String member_ho) {
		int row = 0;
		try {
			PreparedStatement psmt = null;
			String sql = "insert into MEMBER values(?,?,?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, member_id);
			psmt.setString(2, member_pw);
			psmt.setInt(3, member_authority);
			psmt.setString(4, member_zipcode);
			psmt.setString(5, member_dong);
			psmt.setString(6, member_ho);
			row = psmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {

		}
		return row;
	}

	public boolean MemberLogin(String member_id, String member_pw ) {
		PreparedStatement psmt=null;
		ResultSet rs=null;
		boolean check = false;
		try {
			String sql="select MEMBER_ID,MEMBER_PW from MEMBER where MEMBER_ID=?";
			
			psmt=conn.prepareStatement(sql);
			psmt.setString(1, member_id);
			int row = psmt.executeUpdate();
			rs = psmt.executeQuery();
			
			if(row > 0){
				while(rs.next()){
					if(rs.getString(2).equals(member_pw)){
						check = true;
					}else{
						check = false;
					}
				}
			}
			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return check;
	}

	public void MemberIdSearchByZipcode() {
		try {

			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void MemberPwdSearchById() {
		try {

			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void MemberAuthority() {
		try {

			conn.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
