package kr.or.kosta.Dao;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDao {
	DataSource datasource =  null;
	Connection conn = null;
	
	public BoardDao(){
		Context context;
		try {
			context = new InitialContext();
			datasource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}		
	}
	
	public void AllBoardList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public void NoticeBoardList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public void NoticeBoardWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
 	public void NoticeBoardEdit(){
 		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
 	}
 	
	public void NoticeBoardDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	

	public void NoticeBoardReply(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommuBoardList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommuBoardWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommuBoardEdit(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommuBoardDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommuBoardReply(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void GalleryBoardList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void GalleryBoardWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void GalleryBoardEdit(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void GalleryBoardDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void GalleryBoardReply(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void BoardCategoryInfoByCode(int code){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void BoardFileInput(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void BoardFileOutput(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommentWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
 
	public void CommentDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public void CommentList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

}
