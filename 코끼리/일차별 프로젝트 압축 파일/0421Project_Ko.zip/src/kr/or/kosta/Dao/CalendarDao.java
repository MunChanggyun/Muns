package kr.or.kosta.Dao;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CalendarDao {
	DataSource datasource =  null;
	Connection conn = null;
	
	public CalendarDao(){
		Context context;
		try {
			context = new InitialContext();
			datasource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}		
	}
	
	public void CalendarWrite(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public void CalendarList(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	public void CalendarDelete(){
		try{
			conn = datasource.getConnection();
			
			conn.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

}
