package kr.or.kosta.Dto;

public class BoardFileDto {
	private int board_id;
	private String boardfile;
	
	public BoardFileDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BoardFileDto(int board_id, String boardfile) {
		super();
		this.board_id = board_id;
		this.boardfile = boardfile;
	}
	public int getBoard_id() {
		return board_id;
	}
	public void setBoard_id(int board_id) {
		this.board_id = board_id;
	}
	public String getBoardfile() {
		return boardfile;
	}
	public void setBoardfile(String boardfile) {
		this.boardfile = boardfile;
	}
	@Override
	public String toString() {
		return "BoardFileDto [board_id=" + board_id + ", boardfile="
				+ boardfile + "]";
	}
}
