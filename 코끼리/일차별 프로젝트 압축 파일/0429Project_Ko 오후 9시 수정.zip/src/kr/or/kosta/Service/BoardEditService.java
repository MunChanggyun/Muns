package kr.or.kosta.Service;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.BoardDao;
import kr.or.kosta.Dto.BoardDto;

public class BoardEditService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = null;
		
		try{
			String boardTitle = request.getParameter("board_title");
			String boardContent = request.getParameter("board_content");
			int boardIdx = Integer.parseInt(request.getParameter("idx").trim());
			forward = new ActionForward();
			forward.setRedirect(false);
			
			BoardDto boardDto = new BoardDto();
			boardDto.setBoard_title(boardTitle);
			boardDto.setBoard_content(boardContent);
			boardDto.setBoard_id(boardIdx);
			
			BoardDao boardDao = new BoardDao();
			int result = boardDao.BoardEdit(boardDto);
		//	forward.setPath("/upload.file");
		//	forward.setPath("/board/board_content?idx=?.jsp"); // 게시물로 이동
			
			if(result > 0){
				System.out.println("수정 성공");
			}else{
				System.out.println("수정 실패");
			}
			
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
}
