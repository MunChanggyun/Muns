package kr.or.kosta.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


import kr.or.kosta.Dto.GalleryDto;


public class GalleryDao {

   DataSource datasource =  null;
   Connection conn = null;
   Statement stmt = null;
   PreparedStatement pstmt = null;
   ResultSet rs = null;
   
   // 생성자
   public GalleryDao(){
      Context context;
      try {
         context = new InitialContext();
         datasource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
         conn = datasource.getConnection();
      } catch (Exception e) {
         System.out.println(e.getMessage());
      }      
   }
   
   // 전체 게시판 리스트
   public ArrayList<GalleryDto> AllGalleryList(int cpage, int pagesize){
      ArrayList<GalleryDto> gallerylist = null;
      try{
         String sql = "select * from"
               + "(select ROWNUM rn, gallery_id, gallery_title, member_id, gallery_date,"
               + "gallery_like, gallery_hit, gallery_filename, gallery_oirfilename where rn between ? and ?";

         int start = cpage * pagesize - (pagesize - 1);
         int end = cpage * pagesize;

         pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, start);
         pstmt.setInt(2, end);
         rs = pstmt.executeQuery();
         
         gallerylist = new ArrayList<GalleryDto>();
         while(rs.next()){
            GalleryDto gallery = new GalleryDto();
            gallery.setRow_num(rs.getInt("rn"));
            gallery.setGallery_id(rs.getInt("gallery_id")); 
            gallery.setGallery_title(rs.getString("gallery_title"));
            gallery.setMember_id(rs.getString("member_id"));
            gallery.setGallery_date(rs.getDate("gallery_date"));
            gallery.setGallery_like(rs.getInt("gallery_like"));
            gallery.setGallery_hit(rs.getInt("gallery_hit"));
            gallery.setGallery_filename(rs.getString("gallery_filename"));
            gallery.setGallery_orifilename(rs.getString("gallery_oirfilename"));
            gallerylist.add(gallery);
            }
         
         rs.close();
         pstmt.close();
         conn.close();
         
      }catch(Exception e){
         System.out.println(e.getMessage());
      }
      return gallerylist;
   }
   
   // 전체 게시판 게시물 총 건수
   public int AllboardCount(){
      int totalcount = 0;
      try {
         String sql = "select count(*) cnt from gallery";
         stmt = conn.createStatement();
         rs = stmt.executeQuery(sql);
         
         if(rs.next()) {
            totalcount = rs.getInt("cnt");
         }
         
         stmt.close();
         conn.close();
      }catch(Exception e){
         System.out.println(e.getMessage());
      }
      return totalcount;
   }
   
   // 게시글 상세정보
   public GalleryDto BoardgetContentByBoardId(int gallery_id){
      GalleryDto board = null;
      try{
         String sql = "select * from gallery where gallery_id=?";
         pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, gallery_id);
         rs = pstmt.executeQuery();

         if(rs.next()){
            board = new GalleryDto();
            board.setGallery_id(rs.getInt(1));
            board.setGallery_title(rs.getString(2));
            board.setMember_id(rs.getString(3));
            board.setGallery_date(rs.getDate(4));
            board.setGallery_like(rs.getInt(5));
            board.setGallery_hit(rs.getInt(6));
         }
      } catch (Exception e) {
         System.out.println(e.getMessage());
      }
      return board;
   }
   
   // 게시판 글 쓰기
      public int GalleryWrite(GalleryDto gallerydto){
         int rowcount = 0;
         int gallery_id = 0;
         try{
            String sql = "insert into gallery(gallery_id, gallery_title, member_id,"
                     + "gallery_date, gallery_like, gallery_hit values(Gallery_idx.nextval,?,?,sysdate,0,0)";
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, gallerydto.getGallery_title());
            pstmt.setString(2, gallerydto.getMember_id());
            
            rowcount = pstmt.executeUpdate();
            if(rowcount > 0){
               System.out.println("ok");
            }else{
               System.out.println("no");
            }
            
            String get_gallery_sql = "select nvl(max(gallery_id),0) from gallery";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(get_gallery_sql);
            if(rs.next()){
               gallery_id = rs.getInt(1);
            }
            System.out.println("rowcount : " + rowcount);
            
            stmt.close();         
         }catch(Exception e){
            System.out.println("�ㅻ� : " + e.getMessage());
         }
         return gallery_id;
      }
      
      // 게시판 글 삭제
       public int GalleryDelete(int gallery_id) {//gallery_id
          int rowcount = 0;
          try {
          
             String del_gallery_sql = "delete from Gallery where gallery_id=?";
                   //del_gallery_sql
             conn.setAutoCommit(false); // rollback , commit 泥�由� 媛���


             // 寃���湲� ����
             pstmt = conn.prepareStatement(del_gallery_sql);//del_gallery_sql
             pstmt.setInt(1, gallery_id);
             rowcount = pstmt.executeUpdate();

             if (rowcount > 0) {
                conn.commit(); // ����泥�由�
             } else {
                conn.rollback();
             }

             conn.close();
          } catch (Exception e) {
             System.out.println(e.getMessage());
          }
          return rowcount;
       }

       //게시물 조회수 증가
      public int UpBoardHit(int gallery_id) {
         int rowcount = 0;
         try {
            String sql = "update gallery set gallery_hit=gallery_hit+1 where gallery_id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, gallery_id);
            rowcount = pstmt.executeUpdate();

         } catch (Exception e) {
            System.out.println(e.getMessage());
         }
         return rowcount;
      }
       
      // 게시물 좋아요수 증가
      public int UpBoardLike(int gallery_id) {
         int rowcount = 0;
         try {
            String sql = "update gallery set gallery_like=gallery_like+1 where gallery_id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, gallery_id);
            
            rowcount = pstmt.executeUpdate();

            pstmt.close();
            conn.close();
         } catch (Exception e) {
            System.out.println(e.getMessage());
         }
         return rowcount;
      }
}