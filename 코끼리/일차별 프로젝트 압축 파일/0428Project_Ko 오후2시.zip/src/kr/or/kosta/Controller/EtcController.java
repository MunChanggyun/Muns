package kr.or.kosta.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Service.ApartListSearchService;
import kr.or.kosta.Service.ApartListService;
import kr.or.kosta.Service.CalendarDeleteService;
import kr.or.kosta.Service.CalendarInsertOkService;
import kr.or.kosta.Service.CalendarInsertService;
import kr.or.kosta.Service.CalendarListService;
import kr.or.kosta.Service.ReservationDeleteService;
import kr.or.kosta.Service.ReservationListService;
import kr.or.kosta.Service.ReservationWriteService;


@WebServlet("*.etc")
public class EtcController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public EtcController() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doprocess(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doprocess(request, response);
	}
	
	private void doprocess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String RequestURL = request.getRequestURI();
		String ContextPath = request.getContextPath();
		String url_command = RequestURL.substring(ContextPath.length());
		
		System.out.println("url_command : " + url_command);
		
		Action action = null;
		ActionForward forward = null;
	
		if(url_command.equals("/Apart.etc")){
			System.out.println("Apart.etc Controller 탐");
			action =new ApartListService();
			forward= action.execute(request, response);
		}else if(url_command.equals("/ApartSearch.etc")){
			System.out.println("/ApartSearch.etc 탐");
			action =new ApartListSearchService();
			forward= action.execute(request, response);			
		}else if(url_command.equals("/view/calendar/CalendarList.etc")){
			System.out.println("CalendarList.etc 탐");
			action = new CalendarListService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/CalendarInsert.etc")){
			System.out.println("CalendarInsertOk.etc 탐");
			action = new CalendarInsertService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/view/calendar/CalendarDeleteService.etc")){
			System.out.println("CalendarDeleteService.etc 탐");
			action = new CalendarDeleteService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/view/calendar/CalendarInsertOk.etc")){
			System.out.println("CalendarInsertOk.etc탐");
			action = new CalendarInsertOkService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/view/reservation/Reservationlist.etc")){
			action = new ReservationListService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/view/reservation/ReservationDelete.etc")){
			action = new ReservationDeleteService();
			forward= action.execute(request, response);
		}else if(url_command.equals("/view/Reservationinsert.etc")){
			action = new ReservationWriteService();
			forward = action.execute(request, response);
		}
		
		
		
		
		
		
		
		
		
		if(forward !=null){
			if(forward.isRedirect()){
				response.sendRedirect(forward.getPath());
				
			}else{
				System.out.println(forward.getPath());
				RequestDispatcher dis = request.getRequestDispatcher(forward.getPath());
				dis.forward(request, response);
			}
			
			
			
			
		}
	}

}
