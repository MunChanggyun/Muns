package kr.or.kosta.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Service.BoardAllListService;
import kr.or.kosta.Service.BoardDeleteService;
import kr.or.kosta.Service.BoardDetailContentsService;
import kr.or.kosta.Service.BoardEditPageService;
import kr.or.kosta.Service.BoardEditService;
import kr.or.kosta.Service.BoardGalleryListService;
import kr.or.kosta.Service.BoardNoticeListService;
import kr.or.kosta.Service.BoardReWriteService;
import kr.or.kosta.Service.BoardSotongListService;
import kr.or.kosta.Service.BoardWriteService;


@WebServlet("*.board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public BoardController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); 
	    response.setContentType("text/html; charset=UTF-8");
		
		String RequestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String url_command = RequestURI.substring(contextPath.length());
	    
		System.out.println("url_command : " + url_command);
		
		ActionForward forward = null;
		Action action = null;
		
		if(url_command.equals("/AllList.board")){  // 전체 게시판 리스트
			action = new BoardAllListService();
			forward = action.execute(request, response); // 게시글 상세보기
		}else if(url_command.equals("/DetailContents.board")){
			action = new BoardDetailContentsService();
			forward = action.execute(request, response); // 게시글 쓰기
		}else if(url_command.equals("/Write.board")){
			action = new BoardWriteService();
			forward = action.execute(request, response); // 게시글 삭제
		}else if(url_command.equals("/Delete.board")){
			action = new BoardDeleteService();
			forward = action.execute(request, response); // 게시글 수정 페이지로
		}else if(url_command.equals("/toEditPage.board")){
			action = new BoardEditPageService();
			forward = action.execute(request, response); // 게시글 수정
		}else if(url_command.equals("/Edit.board")){
			action = new BoardEditService();
			forward = action.execute(request, response); // 답글 쓰기
		}else if(url_command.equals("/ReWrite.board")){
			action = new BoardReWriteService();
			forward = action.execute(request, response); // 공지 사항 리스트
		}else if(url_command.equals("/Notice.board")){
			action = new BoardNoticeListService();
			forward = action.execute(request, response); // 소통 게시판 리스트
		}else if(url_command.equals("/Sotong.board")){
			action = new BoardSotongListService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/Gallery.board")){ // 갤러리 리스트
			action = new BoardGalleryListService();
			forward = action.execute(request, response);
		}
		
		if(forward != null){
			if(forward.isRedirect()){ // true
				response.sendRedirect(forward.getPath()); // 서버에게 페이지 재요청
			}else{	//false
				RequestDispatcher dis = request.getRequestDispatcher(forward.getPath());
				dis.forward(request, response);
			}
		}
	}

}
