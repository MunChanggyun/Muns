package kr.or.kosta.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Service.MemberIdSearchService;
import kr.or.kosta.Service.MemberJoinOkService;
import kr.or.kosta.Service.MemberDeleteService;
import kr.or.kosta.Service.MemberListService;
import kr.or.kosta.Service.MemberLoginOkService;
import kr.or.kosta.Service.MemberPwdSearchOkService;
import kr.or.kosta.Service.MemberPwdSearchService;



@WebServlet("*.member")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public MemberController() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doprocess(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doprocess(request, response);
	}
	private void doprocess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String RequestURL = request.getRequestURI();
		String ContextPath = request.getContextPath();
		String url_command = RequestURL.substring(ContextPath.length());
		
		System.out.println("url_command : " + url_command);
		Action action = null;
		ActionForward forward = null;
		
		    /*창균 Controller*/
		if(url_command.equals("/MemberJoinOk.member")){
			action= new MemberJoinOkService();
			forward = action.execute(request, response);	
		}else if(url_command.equals("/MemberList.member")){
			action= new MemberListService();
			forward = action.execute(request, response);
		}else if(url_command.equals("/MemberDelete.member")){
			action=new MemberDeleteService();
			forward = action.execute(request, response);
			
			/*찬섭 Controller*/
		}else if(url_command.equals("/MemberLogin.member")){
			action= new MemberLoginOkService();
			forward = action.execute(request, response);
			
		}
		else if(url_command.equals("/MemberIdSearch.member")){
			action= new MemberIdSearchService();
			forward = action.execute(request, response);
			
		}
		else if(url_command.equals("/MemberPwdSearch.member")){
			action= new MemberPwdSearchService();
			forward = action.execute(request, response);
			
		}
		else if(url_command.equals("/MemberPwdSearchOk.member")){
			action= new MemberPwdSearchOkService();
			forward = action.execute(request, response);
			
		}
		
		
		
		
		if(forward !=null){
			if(forward.isRedirect()){
				response.sendRedirect(forward.getPath());
				
			}else{
				System.out.println(forward.getPath());
				RequestDispatcher dis = request.getRequestDispatcher(forward.getPath());
				dis.forward(request, response);
			}	
		}
	}
}
