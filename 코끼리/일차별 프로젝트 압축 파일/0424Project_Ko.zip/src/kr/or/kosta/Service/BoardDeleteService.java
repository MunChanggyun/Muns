package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.BoardDao;

public class BoardDeleteService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		int boardIdx = Integer.parseInt(request.getParameter("idx"));
		BoardDao boardDao = new BoardDao();
		ActionForward forward = null;
		
		try{
			request.setCharacterEncoding("utf-8");
			
			forward = new ActionForward();
			int cpage = Integer.parseInt(request.getParameter("cp"));
			int psize = Integer.parseInt(request.getParameter("ps"));
			if(boardIdx == 0){
				response.sendRedirect("board_list.jsp"); // �Խù��� �ִ� ����Ʈ �������� �Ѿ��
			}
			
			int result = boardDao.BoardDelete(boardIdx);
			
			if(result > 0){
				System.out.println("�� ���� ����");
				request.setAttribute("result", "success");
			}else{
				System.out.println("�� ���� ����");
				request.setAttribute("result", "fail");
			}
			request.setAttribute("boardIdx", boardIdx);
			request.setAttribute("cpage", cpage);
			request.setAttribute("psize", psize);
			
			forward.setRedirect(false);
			forward.setPath("/board/board_deleteok.jsp"); // �Խù��� �ִ� ����Ʈ ������?cpage=?,pasize=?�� �Ѿ��
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
}
