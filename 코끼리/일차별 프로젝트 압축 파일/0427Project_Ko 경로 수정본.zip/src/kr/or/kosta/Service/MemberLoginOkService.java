package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;





public class MemberLoginOkService implements Action{
   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
      System.out.println("들어옴2");
      ActionForward forward = null;
      String memberid = request.getParameter("memberid");
      String memberpw = request.getParameter("memberpw");
      System.out.println(memberid);
      System.out.println(memberpw);
      
      try{
         forward = new ActionForward();
         request.setCharacterEncoding("UTF-8");
         response.setContentType("text/html; charset=UTF-8");
         MemberDao memberDao = new MemberDao();
         System.out.println("들어오지3");
         
         boolean check = memberDao.MemberLogin(memberid, memberpw);
         
         
         System.out.println(check);
         
         if(check==true){
            forward.setRedirect(false);
            forward.setPath("/view/homepage.jsp");
            
         }else{
            forward.setRedirect(false);
            forward.setPath("/view/index_login.jsp");
         }
         
         
      }catch(Exception e){
         System.out.println(e.getMessage());
      }
      return forward;
   }

}