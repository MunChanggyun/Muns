package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.MemberDao;

public class MemberPwdSearchService implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) {
		ActionForward forward = null;	
		String member_id = request.getParameter("member_id");
		String member_dong = request.getParameter("member_dong");
		String member_ho = request.getParameter("member_ho");
        forward = new ActionForward();
		boolean check = false;
		
		System.out.println(member_id);
		System.out.println(member_dong);
		System.out.println(member_ho);
		
		
		try{		
			MemberDao memberDao = new MemberDao();			
			check = memberDao.MemberPwdSearchById(member_id, member_dong, member_ho);
			
			System.out.println(check);
			System.out.println("if타기전");
			if(!check){				
				forward.setRedirect(false);
				forward.setPath("/view/member/member_pwd_search.jsp");
			}else{
				request.setAttribute("member_id",member_id );
				forward.setRedirect(false);
				forward.setPath("/view/member/member_pwd_search_ok.jsp");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
	
}