package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.BoardDao;

public class BoardDeleteService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		int boardIdx = Integer.parseInt(request.getParameter("idx"));
		BoardDao boardDao = new BoardDao();
		ActionForward forward = null;
		
		try{
			request.setCharacterEncoding("utf-8");
			
			forward = new ActionForward();
			int cpage = Integer.parseInt(request.getParameter("cp"));
			int psize = Integer.parseInt(request.getParameter("ps"));
			if(boardIdx == 0){
				response.sendRedirect("board_list.jsp"); // 게시물이 있던 리스트 페이지로 넘어가기
			}
			
			int result = boardDao.BoardDelete(boardIdx);
			
			if(result > 0){
				System.out.println("글 삭제 성공");
				request.setAttribute("result", "success");
			}else{
				System.out.println("글 삭제 실패");
				request.setAttribute("result", "fail");
			}
			request.setAttribute("boardIdx", boardIdx);
			request.setAttribute("cpage", cpage);
			request.setAttribute("psize", psize);
			
			forward.setRedirect(false);
			forward.setPath("/"); // 게시물이 있던 리스트 페이지?cpage=?,pasize=?로 넘어가기
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
}
