package kr.or.kosta.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.kosta.Action.Action;
import kr.or.kosta.Action.ActionForward;
import kr.or.kosta.Dao.BoardDao;
import kr.or.kosta.Dto.BoardDto;

public class BoardCommentDeleteService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		int boardIdx = Integer.parseInt(request.getParameter("boardIdx"));
		int commentIdx = Integer.parseInt(request.getParameter("commentIdx"));
		BoardDao boardDao = new BoardDao();
		BoardDto boardDto = new BoardDto();
		ActionForward forward = null;
		
		try{			
			forward = new ActionForward();
			System.out.println("이은경 똥개");
			/*if(boardIdx == 0){
				response.sendRedirect("/DetailContents.board?boardIdx"+boardIdx); // 원래 있던 페이지로 넘어가기
			}*/
			
			int result = boardDao.CommentDelete(commentIdx);
			
			boardDto = boardDao.BoardgetContentByBoardId(boardIdx);
		    
		    int boardcategoryCode = boardDto.getBoardCategory_code();
		    request.setAttribute("boardcategoryCode", boardcategoryCode);
			if(result > 0){
				System.out.println("댓글 삭제 성공");
				request.setAttribute("result", "success");
			}else{
				System.out.println("댓글 삭제 실패");
				request.setAttribute("result", "fail");
			}
			
			
			forward.setRedirect(false);
			forward.setPath("/DetailContents.board?boardIdx=" + boardIdx + "&boardcategoryCode="+boardcategoryCode); // 상세 게시물 보기로 넘어가기
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return forward;
	}
}
