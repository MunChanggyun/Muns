package kr.or.kosta.Dto;

public class BoardFileDto {
	private int board_id;
	private String board_file;
	private String board_file_oriname;
	
	public BoardFileDto(){ }

	public BoardFileDto(int board_id, String board_file,
			String board_file_oriname) {
		super();
		this.board_id = board_id;
		this.board_file = board_file;
		this.board_file_oriname = board_file_oriname;
	}

	public int getBoard_id() {
		return board_id;
	}

	public void setBoard_id(int board_id) {
		this.board_id = board_id;
	}

	public String getBoard_file() {
		return board_file;
	}

	public void setBoard_file(String board_file) {
		this.board_file = board_file;
	}

	public String getBoard_file_oriname() {
		return board_file_oriname;
	}

	public void setBoard_file_oriname(String board_file_oriname) {
		this.board_file_oriname = board_file_oriname;
	}

	@Override
	public String toString() {
		return "BoardFileDto [board_id=" + board_id + ", board_file="
				+ board_file + ", board_file_oriname=" + board_file_oriname
				+ "]";
	}
	
}
